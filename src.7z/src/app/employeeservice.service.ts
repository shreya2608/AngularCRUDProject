import { Injectable } from '@angular/core';
import { EmployeeForm } from './models/EmployeeForm';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { identifierName } from '@angular/compiler';
import {map} from 'rxjs/operators';
@Injectable({
  providedIn: 'root'
})
export class EmployeeserviceService {
  
  getAllEmployees=this.getAllEmployee();
  constructor(private http:HttpClient) { }
  addEmployee(employee:EmployeeForm){
    return this.http.put<EmployeeForm>("http://localhost:3000/posts",employee)
    
  }
  postEmployee(data:EmployeeForm){
    return this.http.post<EmployeeForm>("http://localhost:3000/posts",data)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  getAllEmployee():Observable<EmployeeForm[]>{
    return this.http.get<EmployeeForm[]>("http://localhost:3000/posts")
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  deleteEmployee(id:number){
    return this.http.delete<EmployeeForm>("http://localhost:3000/posts/"+id)
    .pipe(map((res:any)=>{
      return res;
    }))
  }
  editEmployee(data:EmployeeForm,id:number){
    return this.http.put<EmployeeForm>("http://localhost:3000/posts/"+id,data)
    .pipe(map((res:any)=>{
       return res;}))
  }
}
