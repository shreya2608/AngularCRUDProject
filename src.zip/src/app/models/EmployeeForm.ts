export class EmployeeForm{
    id:number;
    name: string;
    phone: number;
    email: string
}