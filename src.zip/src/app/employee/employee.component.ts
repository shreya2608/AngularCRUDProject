import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl,Validators } from '@angular/forms';
import { EmployeeserviceService } from '../employeeservice.service';
import { EmployeeForm } from '../models/EmployeeForm';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {
  employeeForm: FormGroup;
  employees: EmployeeForm[];
  empObj: EmployeeForm = new EmployeeForm();
  constructor(private _fb: FormBuilder, private employeeService: EmployeeserviceService) { }

  ngOnInit() {
    this.setformState();
    this.employeeService.getAllEmployee().subscribe(list => {
      this.employees = list;
    })
  }
  setformState() {
    this.employeeForm = this._fb.group({
      name: new FormControl('',[Validators.required]),
      phone: new FormControl('', Validators.compose([Validators.required, Validators.pattern("^[0-9]*$"), Validators.minLength(10), Validators.maxLength(10)])),
      email: new FormControl('', Validators.compose([Validators.required, Validators.pattern("^[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*$")]))
    });
  }
  get name(){
    return this.employeeForm.get('name');
  }
  get phone(){
    return this.employeeForm.get('phone');
  }
  get email(){
    return this.employeeForm.get('email');
  }
  invalidValue(){
    alert("Enter valid values")
  }
  postEmployeedetails() {
      this.empObj.name = this.employeeForm.value.name;
      this.empObj.phone = this.employeeForm.value.phone;
      this.empObj.email = this.employeeForm.value.email;
      this.employeeService.postEmployee(this.empObj)
      .subscribe(res => {
        console.log(res);
        alert("Success");
        this.employeeForm.reset();
        window.location.reload();
      },
        err => {
          console.log(err);
          alert("Error");
        });
  }
      onSubmit() {

    if (this.employeeForm.valid) {
      this.employeeService.addEmployee(this.employeeForm.value).subscribe();
      window.location.reload();
    }
  }
  onCancel() {
    this.employeeForm.reset();
  }
  deleteEmployee(emp: any) {
    this.employeeService.deleteEmployee(emp.id)
      .subscribe(res => {
        console.log(res);
        alert("Successfully deleted");
      })
    window.location.reload();
  }
  editEmployee(emp: any) {
    this.empObj.id = emp.id;
    this.employeeForm.controls["name"].setValue(emp.name);
    this.employeeForm.controls["phone"].setValue(emp.phone);
    this.employeeForm.controls["email"].setValue(emp.email);
  }
  EditEmployeedetails() {
    this.empObj.name = this.employeeForm.value.name;
    this.empObj.phone = this.employeeForm.value.phone;
    this.empObj.email = this.employeeForm.value.email;
    this.employeeService.editEmployee(this.empObj, this.empObj.id)
      .subscribe(res => {
        alert("Updated employee");
        window.location.reload();
      })
  }
}